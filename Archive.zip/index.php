<!DOCTYPE html>
<html lang="en-US">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <title>Big Deal - Leading Grocery Retail Chain - Big Deal</title>
  <meta name="description"
    content="Startup India experts help you to register a LLP within 5 days. Learn more about LLP Registration Process | LLP Meaning | LLP Agreement | LLP Name Search">
  <meta name="keywords"
    content="LLP, Limited Liability Partnership, LLP full form, LLP Registration, llp meaning, llp means, llp act ">

  <meta property="og:site_name" content="Big Deal">
  <meta property="og:locale" content="en_US">
  <meta property="og:title" content="Big Deal - Leading Grocery Retail Chain - Big Deal">
  <meta property="og:url" content="https://www.startupindia.com/llp-registration">
  <meta property="og:description"
    content="Startup India experts help you to register a LLP within 5 days. Learn more about LLP Registration Process | LLP Meaning | LLP Agreement | LLP Name Search">
  <meta property="og:image" content="https://www.startupindia.com/assets/img/company-registration.jpg">
  <meta property="og:image:alt" content="company registration">
  <meta property="og:type" content="service">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:domain" content="www.startupindia.com">
  <!-- <meta name="twitter:site" content="@om_sai_group"> -->
  <meta name="twitter:title" content="Big Deal - Leading Grocery Retail Chain - Big Deal">
  <meta name="twitter:url" content="https://www.startupindia.com/llp-registration">
  <meta name="twitter:description"
    content="Startup India experts help you to register a LLP within 5 days. Learn more about LLP Registration Process | LLP Meaning | LLP Agreement | LLP Name Search">
  <meta name="twitter:image" content="https://www.startupindia.com/assets/img/company-registration.jpg">
  <meta itemprop="name" content="Big Deal - Leading Grocery Retail Chain - Big Deal">
  <meta itemprop="url" content="https://www.startupindia.com/llp-registration">
  <meta itemprop="description"
    content="Startup India experts help you to register a LLP within 5 days. Learn more about LLP Registration Process | LLP Meaning | LLP Agreement | LLP Name Search">
  <meta itemprop="image" content="https://www.startupindia.com/assets/img/company-registration.jpg">
  <link rel="canonical" href="https://www.startupindia.com/llp-registration">

  <link rel="icon" href="assets/img/APPOINTMENT-300x300.png" sizes="16x16" type="image/png">
  <meta name="robots" content="index, follow">
  <meta http-equiv="cache-control" content="max-age=0" />
  <meta http-equiv="cache-control" content="no-cache" />
  <meta http-equiv="pragma" content="no-cache" />

  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "ProfessionalService",
      "brand": "Startup India",
      "name": "Startup India",
      "image": "https://www.startupindia.com/assets/img/startup-club-india-logo.webp",
      "description": "Hiring hr consulting firms for your company is not a difficult task. Om sai group is most trusted recruitment agency which provides authentic job candidates near me.",
      "aggregateRating": {
        "@type": "aggregateRating",
        "ratingValue": "4.8",
        "reviewCount": "450"
      },
      "@id": "",
      "url": "https://www.startupindia.com/",
      "priceRange": "$$$$",
      "telephone": "+919468065626",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "B-94, Freedom Fighter Enclave, Neb sarai, Ignou Main Road",
        "addressLocality": "New Delhi",
        "postalCode": "110068",
        "addressCountry": "IN"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": 28.5069712,
        "longitude": 77.320955
      },
      "hasMap": "https://www.google.com/maps/dir/28.5069712,77.320955/startup+club+india/@20.5038258,67.1356667,5z/data=!3m1!4b1!4m9!4m8!1m1!4e1!1m5!1m1!1s0x3bae14598469e773:0xc4cb4a97ac6ce32a!2m2!1d77.6176304!2d12.9358167",
      "openingHoursSpecification": {
        "@type": "OpeningHoursSpecification",
        "dayOfWeek": [
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
          "Sunday"
        ],
        "opens": "00:00",
        "closes": "23:59"
      },
      "sameAs": [
        "https://www.facebook.com/startupindia/",
        "https://www.startupindia.com/"
      ]
    }
  </script>

  <!-- Header Section HTML -->
  <?php include 'common/stylesheet.php'; ?>
  <!-- Header Section HTML -->
</head>

<body>
  <!-- Header Section HTML -->
  <?php include 'common/header.php'; ?>
  <!-- Header Section HTML -->

  <!-- Top Section HTML -->
  <section class="banner-home overflow-hidden pt-lg-100 pt-md-90 pt-sm-80 pt-xs-70">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-6">
          <div class="banner-home__content pb-lg-60 pb-md-50 pb-sm-45 pb-xs-40">
            <h6 class="sub-title color-white mb-20 mb-sm-15 mb-xs-10 d-inline-block">Welcome To <span>Consulter</span>
              Consultancy</h6>
            <h1 class="title color-white fw-bold mb-20 mb-sm-15 mb-xs-10">Build Up Your Business Strategy</h1>

            <div class="description font-la color-white mb-45 mb-sm-15 mb-md-30 mb-sm-25 mb-xs-20">
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.
              </p>
            </div>

            <div class="theme-btn__wrapper d-flex flex-wrap">
              <div class="btn-box">
                <button href="blog.html" class="btn btn-primary">
                  <span>Find Consultant</span>
                </button>
              </div>
              <div class="btn-box">
                <button href="about.html" class="btn btn-border">
                  <span>Read More</span></button>
              </div>
            </div>
          </div>

        </div>

        <div class="col-md-6">
          <div class="banner-home__media">
            <img src="assets/img/banner-start.svg" class="img-fluid start" alt="">
            <img src="assets/img/big-deal-supermart.jpg" class="img-fluid" alt="">
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Top Section HTML -->

  <!-- Reasons to Start -->
  <section class="reason_start">
    <div class="container">
      <div class="subheading">
        <h3>So many reasons to <span class="main-green">start</span></h3>
      </div>
      <div class="feat_right_section">
        <div class="row">
          <div class="col-6 col-md-3">
            <div class="feat_card">
              <img src="assets/img/discount.svg" alt="Affordable Pricing">
              <h3>Affordable Pricing</h3>
              <p>We are going to open your store in 45 days, so be ready for the big deals!</p>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="feat_card">
              <img src="assets/img/savings.svg" alt="Timely Delivered">
              <h3>Best Margin</h3>
              <p>No one can present you this margin. We are going to give the best deals ever!</p>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="feat_card">
              <img src="assets/img/code_review.svg" alt="Experienced Team">
              <h3>Best Software</h3>
              <p>Having the best software made us the superior ones among all.</p>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="feat_card">
              <img src="assets/img/breakfast.svg" alt="Trusted Partner">
              <h3>Great Product Offers</h3>
              <p>Our offers can leave you in astonishment.</p>
            </div>
          </div>
          <!-- <div class="col-12 col-md-4">
              <div class="feat_card">
                <img src="assets/img/heart.svg" alt="Trusted Partner">
                <h3>Branding</h3>
                <p>Our branding has always had a different fan base.</p>
              </div>
            </div>
            <div class="col-12 col-md-4">
              <div class="feat_card">
                <img src="assets/img/heart.svg" alt="Trusted Partner">
                <h3>Digital Promotion</h3>
                <p>We are opt for the best digital branding ever.</p>
              </div>
            </div> -->
        </div>
      </div>
    </div>
    </div>
  </section>
  <!-- Reasons to Start -->

  <!-- Featured On Start-->
  <section class="reason_start featured-on">
    <div class="container">
      <div class="subheading">
        <h3>Featured On</h3>
      </div>
      <div class="feat_right_section">
        <div class="row flex-nowrap overflow-auto">
          <div class="col-9 col-md-4">
            <a href="https://hindustanbytes.com/g-fresh-mart-the-most-trusted-supermarket-franchise">
              <div class="feat_card">
                <img class="mb-0" src="assets/img/hindustanBytes.png" alt="Affordable Pricing">
              </div>
            </a>
          </div>
          <div class="col-10 col-md-4">
            <a
              href="https://i0.wp.com/bigdealsupermart.com/wp-content/uploads/2022/06/enterprenuer-hunt.png?fit=1024%2C199&ssl=1">
              <div class="feat_card">
                <img class="mb-0" src="assets/img/entreprenuerHunt.png" alt="Timely Delivered">
              </div>
            </a>
          </div>
          <div class="col-10 col-md-4">
            <a
              href="https://m.dailyhunt.in/news/india/english/josh+bharat-epaper-dh832812b9d1ff451aa43380d9b51fa20e/gfresh+mart+the+most+trusted+supermarket+franchise-newsid-dh832812b9d1ff451aa43380d9b51fa20e_35eee740e41811ecb7affd7a29584364">
              <div class="feat_card">
                <img class="mb-0" src="assets/img/DailyHunt.png" alt="Experienced Team">
              </div>
            </a>
          </div>
          <!-- <div class="col-12 col-md-4">
              <div class="feat_card">
                <img src="assets/img/heart.svg" alt="Trusted Partner">
                <h3>Branding</h3>
                <p>Our branding has always had a different fan base.</p>
              </div>
            </div>
            <div class="col-12 col-md-4">
              <div class="feat_card">
                <img src="assets/img/heart.svg" alt="Trusted Partner">
                <h3>Digital Promotion</h3>
                <p>We are opt for the best digital branding ever.</p>
              </div>
            </div> -->
        </div>
      </div>
    </div>
    </div>
  </section>
  <!-- Featured On End -->

  <!-- Quick Call to Action HTML -->
  <?php include 'common/quick-cta.php'; ?>
  <!-- Quick Call to Action HTML -->

  <!-- Services HTML -->
  <article class="service_article">
    <section class="services_sec">
      <div class="container">
        <div class="row">
          <div class="col-12 col-md-5 col-lg-6">
            <div class="service_content">
              <h3>Why Choose Big Deal Supermart?</h3>
              <p>When it comes to starting a grocery store, there are many factors to consider. One important decision
                is whether to start an independent store or a franchise. There are pros and cons to both, but we think
                there are some compelling reasons to choose a franchise grocery store like <span class="main-green">G
                  Fresh</span> Mart.</p>
              <p>For one, as a franchisee you benefit from the established brand and reputation of the franchisor. This
                can help attract customers and build trust right from the start. You also get access to their resources,
                which can be helpful in getting your business up and running quickly and efficiently.</p>
              <!-- <p>Another big advantage of choosing a franchise is that you have the support of the franchisor and other
                franchisees. This can be invaluable as you navigate the challenges of starting and growing your
                business. When you become part of a franchise network, you tap into a wealth of knowledge and experience
                that can help you overcome obstacles and reach your goals.</p>
              <p>Of course, there are some disadvantages to franchises as well, such as the initial cost and ongoing
                fees associated with being a franchisee. But we believe the benefits outweigh the drawbacks, which is
                why we encourage interested entrepreneurs to explore opening a <span class="main-green">G Fresh</span>
                Mart franchise grocery store.</p>
              <p>Franchise grocery stores are a great way to get into the food business. We offer a variety of benefits
                that make them an attractive option for those looking to start their own business.</p>
              <p>Reliance Supermarket Franchise is one of the leading grocery store franchises in India. It offers a low
                cost franchise option that is perfect for those looking to start their own business. The company has a
                wide range of products and services that make it an ideal choice for those looking to start their own
                franchise business.</p> -->
              <!-- <p><img src="assets/img/check.svg" alt="check"> Feasibility Studies & Business Plans</p> -->
              <div class="btn-box">
                <button class="btn btn-primary" data-target="#enquiryModal" data-toggle="modal">
                  <span>Consult Now</span>
                </button>
              </div>
            </div>
          </div>
          <div class="col-12 col-md-7 col-lg-6 mt-5">
            <div class="row">
              <div class="col-6 col-md-6 col-lg-6">
                <div class="services_card card_margin">
                  <div class="bg-private_limited_company_registration service_img_sprit"></div>
                  <div class="serv_card_cont">
                    <h2><a href="private-limited-company-registration"
                        title="Private Limited Company Registration">Opening in 45 Days</a></h2>
                  </div>
                </div>
                <div class="services_card">
                  <div class="bg-trademark_registration service_img_sprit"></div>
                  <div class="serv_card_cont">
                    <h2><a href="trademark-registration" title="Trademark Registration">Best Margin</a></h2>
                  </div>
                </div>
                <div class="services_card">
                  <div class="bg-ngo_registration service_img_sprit"></div>
                  <div class="serv_card_cont">
                    <h2><a href="online-accounting-and-book-keeping-services" title="Online Accouting Services">Best
                        Software</a></h2>
                  </div>
                </div>
              </div>
              <div class="col-6 col-md-6 col-lg-6">
                <div class="services_card">
                  <div class="bg-one_person_company service_img_sprit"></div>
                  <div class="serv_card_cont">
                    <h2><a href="appointment-of-directors-in-a-company" title="Appointment of Director">Great Product
                        Offers</a></h2>
                  </div>
                </div>
                <div class="services_card">
                  <div class="bg-one_person_company service_img_sprit"></div>
                  <div class="serv_card_cont">
                    <h2><a href="appointment-of-directors-in-a-company" title="Appointment of Director">Branding</a>
                    </h2>
                  </div>
                </div>
                <div class="services_card">
                  <div class="bg-one_person_company service_img_sprit"></div>
                  <div class="serv_card_cont">
                    <h2><a href="appointment-of-directors-in-a-company" title="Appointment of Director">Digital
                        Promotion</a></h2>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>

        <div class="why_startups">
          <div class="row">
            <div class="col-lg-12">
              <div class="subheading">
                <h3><span class="main-green">G-Fresh</span> Franchise Model</h3>
              </div>
              <p>Franchise grocery stores are a type of business model in which an independent grocer partners with a
                larger grocery store chain. The Independent grocer benefits from the economies of scale, branding, and
                marketing of the franchisor, while the franchisor expands its reach into new markets.</p>
              <p>The most common type of franchise agreement between an independent grocer and a franchisor is a
                licensing agreement. In this type of agreement, the independent grocer pays the franchisor a licensing
                fee in exchange for the right to use the franchisor's name, logo, and other intellectual property. The
                independent grocer also agrees to follow the franchisor's operating procedures and standards.</p>
              <p>Reliance Supermarkets is one of the largest grocery store chains in India with over 1000 stores across
                the country. Reliance Supermarkets offers a low-cost franchise model that is ideal for small businesses
                looking to enter the retail food sector. Under this model, franchisees are given access to Reliance
                Supermarkets' brand name, logo, store design, and merchandise. Franchisees are also required to follow
                Reliance Supermarkets' operating procedures and standards.</p>
              <p>The benefits of partnering with Reliance Supermarkets include exposure to a large customer base,
                economies of scale, and access to best-in-class infrastructure and technology.</p>
              <h3>Requirements Of The New Franchise Model</h3>
              <p>If you're thinking of becoming a franchise model, there are a few things you need to take into account
                before getting started. </p>
              <p>For starters, you'll need to have an appointment in order to fix a professional demeanor.</p>
              <p>Followed by site survey, which needs to be done in order to determine whether or not your location is
                suitable for a franchise.</p>
              <p>Once that's out of the way, you'll need to go through a verification process with the franchisor in
                order to make sure you meet all the requirements.</p>
              <p>After that, it's simply a matter of activating your area code and handling over the welcome kit to the
                new franchisee.</p>
              <p>Finally, you'll need to be present for the opening of the franchise and there goes the kick start boon
                for your business inclinations.</p>
              <h3>Big Deal Supermart Super Market Franchise Model</h3>
              <p>For entrepreneurs looking to start their own business, a franchise supermarket is a great option. With
                the support of an experienced team and the backing of a well-known brand, franchise supermarket owners
                can enjoy all the benefits of owning their own business while providing customers with a convenient
                one-stop shopping experience. The experience include - </p>
              <p>Product Retailers of groceries, toys, baked goods, stationery, personal care items, travel accessories,
                books and periodicals, drinks, frozen foods and ice cream, fruits and vegetables, cigarettes, and other
                goods.</p>
              <p>Company* Support for Accounting, Purchasing, and Operations, Promotional materials, Assistance Outdoor
                advertising, Online Media Ad Training, Employee Training, and T-Shirts *Monthly income of about Rs. 2 to
                5 lacs.</p>
            </div>
          </div>
        </div>
      </div>
      </div>
    </section>
    <!-- Services HTML -->


    <section class="section section-lg bg-default about-us">
      <div class="container container-1">
        <div class="row row-30 row-lg align-items-center">
          <div class="col-lg-6">
            <div class="image-group image-group-1 parallax-scene-js d-none d-xl-block"
              style="transform: translate3d(0px, 0px, 0px); transform-style: preserve-3d; backface-visibility: hidden;">
              <div class="image-group-item-6">
                <div class="layer" data-depth=".2"
                  style="transform: translate3d(-0.0566179px, -11.256px, 0px); transform-style: preserve-3d; backface-visibility: hidden; position: relative; display: block; left: 0px; top: 0px;">
                  <svg width="1612" height="1002" viewBox="0 0 1612 1002" fill="none" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <path
                      d="M11.8392 570.537C-28.6902 721.794 347.277 506.528 701.716 601.5C1077.88 702.292 1389.87 1214.96 1525.17 710.003C1662.36 198.016 877.478 257.266 501.318 156.474C125.159 55.682 112.637 194.353 11.8392 570.537Z"
                      fill="#FFF8F6"></path>
                    <path
                      d="M11.8392 570.537C-28.6902 721.794 347.277 506.528 701.716 601.5C1077.88 702.292 1389.87 1214.96 1525.17 710.003C1662.36 198.016 877.478 257.266 501.318 156.474C125.159 55.682 112.637 194.353 11.8392 570.537Z"
                      fill="url(#pattern0)" fill-opacity="0.2"></path>
                    <defs>
                      <pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1">
                        <use xlink:href="#image0" transform="translate(0 -0.163391) scale(0.000249938 0.000589419)">
                        </use>
                      </pattern>
                    </defs>
                  </svg>
                </div>
              </div>
              <div class="image-group-item-1">
                <div class="layer" data-depth=".5"
                  style="transform: translate3d(-0.141545px, -28.14px, 0px); transform-style: preserve-3d; backface-visibility: hidden; position: absolute; display: block; left: 0px; top: 0px;">
                  <img src="./assets/img/image-01-445x453.png" alt="" width="445" height="453">
                </div>
              </div>
              <div class="image-group-item-2">
                <div class="layer" data-depth=".6"
                  style="transform: translate3d(-0.169854px, -33.768px, 0px); transform-style: preserve-3d; backface-visibility: hidden; position: absolute; display: block; left: 0px; top: 0px;">
                  <img src="assets/img/image-02-388x378.png" alt="" width="388" height="378">
                </div>
              </div>
              <div class="image-group-item-3">
                <div class="layer" data-depth=".8"
                  style="transform: translate3d(-0.226471px, -45.024px, 0px); transform-style: preserve-3d; backface-visibility: hidden; position: absolute; display: block; left: 0px; top: 0px;">
                  <img src="assets/img/image-03-289x382.png" alt="" width="289" height="382">
                </div>
              </div>
              <div class="image-group-item-4">
                <div class="layer" data-depth=".4"
                  style="transform: translate3d(-0.113236px, -22.512px, 0px); transform-style: preserve-3d; backface-visibility: hidden; position: absolute; display: block; left: 0px; top: 0px;">
                  <img src="assets/img/image-04-544x495.png" alt="" width="544" height="495">
                </div>
              </div>
              <div class="image-group-item-5">
                <div class="layer" data-depth=".8"
                  style="transform: translate3d(-0.226471px, -45.024px, 0px); transform-style: preserve-3d; backface-visibility: hidden; position: absolute; display: block; left: 66px; top: 44px;">
                  <img src="assets/img/image-05-295x327.png" alt="" width="295" height="327">
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-5 col-xl-4 offset-lg-1">
            <h2 class="wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">About Us</h2>
            <p class="big wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;"><span
                class="main-green">G Fresh</span> Mart is the best supermarket franchise in India. We offer a wide range
              of products and services that are designed to meet the needs of our customers. We have a large network of
              stores across the country, and our franchisees are spread across all states and union territories.</p>
            <p class="big wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">We offer a wide variety
              of products, including fresh fruits and vegetables, meat, poultry, fish, dry goods, dairy products,
              household items, and personal care products. We also have a wide range of services, including home
              delivery, online ordering, and customer loyalty programs.</p>
            <p class="big wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">We are committed to
              providing our customers with the best possible shopping experience, and our franchisees are an integral
              part of our success. If you are interested in joining our team, please contact us today.</p>
          </div>
        </div>
      </div>
    </section>
  </article>




  <!-- Why Us Section HTML -->
  <section class="ecomm_faq_sec">
    <div class="container">
      <div class="row flex-nowrap overflow-auto">
        <div class="col-10 col-md-6 col-lg-4 offset-lg-2">
          <div class="ecomm_get_here_card">
            <h3>What you get here?</h3>
            <div class="get_here_point">
              <p><img src="assets/img/check.svg" alt="check"> 100% Technical Support</p>
              <p><img src="assets/img/check.svg" alt="check"> Server Management</p>
              <p><img src="assets/img/check.svg" alt="check"> Trusted Technical Partner</p>
              <p><img src="assets/img/check.svg" alt="check"> Easy Meetings with Executive</p>
            </div>
          </div>
        </div>
        <div class="col-10 col-md-6 col-lg-4">
          <div class="ecomm_get_here_card">
            <h3>What others don't provide?</h3>
            <div class="get_here_point">
              <p><img src="assets/img/criss-cross.svg" alt="close"> No After Sales Support</p>
              <p><img src="assets/img/criss-cross.svg" alt="close"> Self Server Handling</p>
              <p><img src="assets/img/criss-cross.svg" alt="close"> No Technical Support</p>
              <p><img src="assets/img/criss-cross.svg" alt="close"> No Executive Available</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Why Us Section HTML -->

  <!-- Testimonial Section HTML -->
  <section class="testimonial">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="subheading">
            <h3><img src="assets/img/google-logo.png" alt=""> Reviews</h3>
          </div>
        </div>
      </div>
      <div id="carouselExampleControls1" class="carousel slide testi_carousel" data-ride="carousel">
        <?php include 'common/testimonial.php'; ?>
        <!-- <a class="carousel-control-prev" href="#carouselExampleControls1" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls1" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a> -->
      </div>
    </div>
  </section>
  <!-- Testimonial Section HTML -->


  <!-- FAQs Section HTML -->
  <section class="faqs">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="subheading">
            <p>FAQs</p>
            <h3>Still have <strong>Questions?</strong></h3>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-12 col-md-10 offset-md-1">
          <div id="accordion">
            <div class="card">
              <div class="card-header" id="headingOne">
                <h5 class="mb-0">
                  <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true"
                    aria-controls="collapseOne">
                    How much do i have to invest to open a Big Deal Supermart franchise?
                  </button>
                </h5>
              </div>

              <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                <div class="card-body">
                  A Big Deal Supermart franchise supermarket is a grocery store that offers a
                  wide variety of food and
                  household items. It is one of the best supermarket franchises in India with a good reputation. You can
                  get a reliable and affordable supermarket franchise from us. The investment required to open a <span
                    class="main-green">G-FRESH</span> Mart franchise is between Rs 10 lakhs to Rs 20 lakhs, with regards
                  to differentiation in factor like location, stock up inventory, specifications for the store and so
                  on.
                </div>
              </div>
            </div>
            <div class="card">
              <div class="card-header" id="headingTwo">
                <h5 class="mb-0">
                  <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="false" aria-controls="collapseTwo">
                    What is the land requirement for opening a Big Deal Supermart franchise?
                  </button>
                </h5>
              </div>
              <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                <div class="card-body">
                  In order to open a Big Deal Supermart franchise, you will need a minimum of
                  500 square feet of land to 10,000 square feet. It also depends on the requirements for loading dock
                  and at least 20 parking spaces.
                </div>
              </div>
            </div>
            <div class="card">
              <div class="card-header" id="headingThree">
                <h5 class="mb-0">
                  <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree"
                    aria-expanded="false" aria-controls="collapseThree">
                    What type of stores Big Deal Supermart opens?
                  </button>
                </h5>
              </div>
              <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                <div class="card-body">
                  Big Deal Supermart is a supermarket franchise that offers a variety of store
                  types to meet the needs of our
                  customers. We have small, medium, and large stores depending on the amount of space available in your
                  area. We offer a variety of services such as grocery delivery, online ordering, and more. And all of
                  it comes under the strategy of FOFO model, they have been following since the beginning.
                </div>
              </div>
            </div>
            <div class="card">
              <div class="card-header" id="headingFour">
                <h5 class="mb-0">
                  <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFour"
                    aria-expanded="false" aria-controls="collapseFour">
                    How many days you‘ll take to open a Big Deal Supermart franchise?
                  </button>
                </h5>
              </div>
              <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
                <div class="card-body">
                  The size of the store is one of the biggest factors in determining the time it will take for opening a
                  supermarket franchise. But with <span class="main-green">G Fresh</span> Mart, we can assure you of
                  setting up a franchise in not more than 45 days.
                </div>
              </div>
            </div>
            <div class="card">
              <div class="card-header" id="headingFive">
                <h5 class="mb-0">
                  <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFive"
                    aria-expanded="false" aria-controls="collapseFive">
                    How much royalty fee do i have to pay for Big Deal Supermart franchise?
                  </button>
                </h5>
              </div>
              <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordion">
                <div class="card-body">
                  For the initial six months, you are not required to pay any royalties. Additionally, if your turnover
                  is less than $10 lacs, we don't impose any royalty fees. We impose a 1% royalty fee on any monthly
                  revenue that is greater than 10 lacs.
                </div>
              </div>
            </div>
            <div class="card">
              <div class="card-header" id="headingSix">
                <h5 class="mb-0">
                  <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseSix"
                    aria-expanded="false" aria-controls="collapseSix">
                    What is the process of opening a supermarket franchise?
                  </button>
                </h5>
              </div>
              <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordion">
                <div class="card-body">
                  The first step in opening a supermarket franchise is to contact the franchisor and request more
                  information.Once you have decided on a franchise, you will need to fill out a Franchise Agreement and
                  pay the initial franchise fee.
                  <br><br>
                  After your Franchise Agreement has been approved, you will need to find a suitable location for your
                  supermarket. Once you have found a location, you will need to build or renovate the store according to
                  the franchisor's specifications. After your store is built or renovated, you will need to stock it
                  with groceries and hire staff.
                </div>
              </div>
            </div>
            <div class="card">
              <div class="card-header" id="headingSeven">
                <h5 class="mb-0">
                  <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseSeven"
                    aria-expanded="false" aria-controls="collapseSeven">
                    Can i open more than one supermart franchise?
                  </button>
                </h5>
              </div>
              <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordion">
                <div class="card-body">
                  The answer is yes, you can certainly open multiple supermarket franchises. In fact, many businesses
                  choose to do this in order to expand their reach and tap into new markets.
                  <br><br>
                  There are a few things to keep in mind if you're thinking about opening multiple supermarket
                  franchises. First, you'll need to make sure that you have the capital necessary to invest in
                  additional stores. Secondly, you'll need to find locations that are feasible for your new stores.
                  <br><br>
                  If you're able to successfully navigate these challenges, then opening multiple supermarket franchises
                  can be a great way to grow your business. Just be sure to do your homework and plan carefully before
                  making any major decisions.
                </div>
              </div>
            </div>
            <div class="card">
              <div class="card-header" id="headingEight">
                <h5 class="mb-0">
                  <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseEight"
                    aria-expanded="false" aria-controls="collapseEight">
                    How many products can we sell in the Big Deal Supermart franchise?
                  </button>
                </h5>
              </div>
              <div id="collapseEight" class="collapse" aria-labelledby="headingEight" data-parent="#accordion">
                <div class="card-body">
                  The Big Deal Supermart franchise supermarket is one of the best in India. It
                  has a wide range of products
                  that it sells at its outlets. There are approximately 20000+ products that we offer at our Big Deal Supermart. And these includes, Beverages, Groceries, Fruits And
                  Vegetables, Health And Beauty Products and Snacks.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- FAQs Section HTML -->

  <!-- Quick Benefits HTML -->
  <section class="quick_benefit">
    <div class="container">
      <div class="subheading">
        <h3>Wide variety of <span class="main-green">Popular</span> Brands</h3>
      </div>
      <ul class="first_list">
        <li><img src="assets/img/2.webp" alt="check border"></li>
        <li><img src="assets/img/7.webp" alt="check border"></li>
        <li><img src="assets/img/6.webp" alt="check border"></li>
        <li><img src="assets/img/5.webp" alt="check border"></li>
        <li><img src="assets/img/4.webp" alt="check border"></li>
        <li><img src="assets/img/3.webp" alt="check border"></li>
        <li><img src="assets/img/1.webp" alt="check border"></li>
      </ul>
      <ul class="second_list">
        <li><img src="assets/img/Britannia_Industries.png" alt="check border"></li>
        <li><img src="assets/img/Haldiram's_Logo.png" alt="check border"></li>
        <li><img src="assets/img/Kwality_Walls_logo.png" alt="check border"></li>
        <li><img src="assets/img/McCain-Logo.png" alt="check border"></li>
      </ul>
    </div>
  </section>
  <!-- Quick Benefits HTML -->

  <section class="blue-bg">
    <div data-vc-parallax="1.5"
      data-vc-parallax-image="https://motivoweb.com/ruya/demo/wp-content/uploads/2019/11/main-landing.png"
      class="vc_row wpb_row vc_row-fluid landing_bg vc_custom_1572638352805 vc_row-has-fill vc_general vc_parallax vc_parallax-content-moving bg-dark white_txt svg_none svg_bottom_none  svg_bottom"
      style="
">

      <div class="particles2"><span class="shape-one"></span><span class="shape-two"></span><span
          class="shape-three"></span><span class="shape-four"></span><span class="shape-five"></span></div>
      <div class="mo-vc-row-ovelay" style=""></div>
      <div class="container main-container">
        <div class="wpb_column vc_column_container vc_col-sm-12 mo-column-63821a71ef788">
          <div class="vc_column-inner">
            <div class="wpb_wrapper-inner">
              <div class="wpb_text_column wpb_content_element ">
                <div class="wpb_wrapper text-center">
                  <div class="logo justify-content-center mb-20">
                    <a href="index">
                      <img src="assets/img/big-deal.webp" alt="startup india logo">
                    </a>
                  </div>
                  <h2 class="text-center">Build a beautiful website right now!</h2>
                  <p class="text-center text-white">We create this design with love and care to assure our
                    customer to get everything for start
                    Purchase Business Marketing HTML Template</p>
                  <div class="btn-box">
                    <button type="submit" class="btn btn-primary">
                      <span>Purchase</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer HTML -->
  <?php include 'common/footer.php'; ?>
  <!-- Footer HTML -->

  <!-- Enquiry Modal -->
  <!-- Modal -->
  <div class="modal fade" id="enquiryModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Enquire Now</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form method="POST" action="./ajax/contact.php" id="sidebar-form">
            <div class="row">
              <div class="col-12 col-md-12">
                <div class="form-group">
                  <input type="text" class="form-control" name="name" id="exampleInputEmail1"
                    aria-describedby="emailHelp" placeholder="NAME">
                  <div>
                    <span class="prettyprint" id="name_error"></span>
                  </div>
                </div>
              </div>
              <div class="col-12 col-md-12">
                <div class="form-group">
                  <input type="text" class="form-control" name="email" id="exampleInputEmail1"
                    aria-describedby="emailHelp" placeholder="EMAIL ADDRESS">
                  <div>
                    <span class="prettyprint" id="email_error"></span>
                  </div>
                </div>
              </div>
              <div class="col-12 col-md-12">
                <div class="form-group">
                  <input type="text" class="form-control" name="contact" id="exampleInputEmail1"
                    aria-describedby="emailHelp" placeholder="CONTACT NUMBER">
                  <div>
                    <span class="prettyprint" id="contact_error"></span>
                  </div>
                </div>
              </div>
              <div>
                <span class="prettyprint text-center" id="thank_you_msg_sidebar"></span>
              </div>
              <div class="col-12 col-md-6 offset-md-3">
                <button type="submit" class="btn btn-block btn-secondary">Submit</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- Enquiry Modal -->

  <!-- Scripts -->
  <?php include 'common/scripts.php'; ?>
  <!-- Scripts -->

</body>

</html>