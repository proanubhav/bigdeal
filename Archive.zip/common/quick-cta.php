<section class="quick_call">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-8 col-lg-9">
                <p>Limited Offer</p>
                <h4>Schedule a <strong>free</strong> consultation</h4>
            </div>
            <div class="col-6 col-md-4 col-lg-3">
                <div class="btn-box">
                    <button class="btn btn-primary" data-target="#enquiryModal" data-toggle="modal">
                        <span>Get Quote</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</section>