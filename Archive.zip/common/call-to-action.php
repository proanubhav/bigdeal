<!-- <section class="cta_first">
    <div class="container">
      <div class="row">
        <div class="col-md-10 offset-md-1 col-lg-8 offset-lg-2">
          <div class="section_heading">
            <h2>Stop <strong>Thinking</strong> for Legal Compliances!</h2>
            <p>We are here to assist you in respect of all applicable legal compliances for starting a business effectively and efficiently.</p>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-10 offset-md-1 col-lg-8 offset-lg-2">
          <div class="cta_content">
            <button class="btn btn-secondary">Try it now</button>
          </div>
        </div>
      </div>
    </div>
  </section> -->