<section class="mobile_footer">
    <ul>
      <li><img src="assets/img/whatsapp.svg" alt="whatsapp social handle"></li>
      <li><img src="assets/img/email.svg" alt="Email"></li>
      <li>
        <button class="btn btn-secondary">Call Now</button>
      </li>
      <li>
        <button class="btn btn-primary">Enquire Now</button>
      </li>
    </ul>
  </section>