<!-- <ol class="carousel-indicators">
  <li data-target="#carouselExampleControls1" data-slide-to="0" class="active"></li>
  <li data-target="#carouselExampleControls1" data-slide-to="1"></li>
  <li data-target="#carouselExampleControls1" data-slide-to="5"></li>
</ol> -->
<div class="carousel-inner">
  <div class="carousel-item active">
    <div class="testi_card_area">
      <div class="row flex-nowrap overflow-auto">
        <div class="col-10 col-md-4">
          <div class="testi_card">
            <div class="testi_card_1">
              <ul>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
              </ul>
              <p>company is very good and good environment for working here. the sir is very supportive and they inspire and motivate me.... <a href="https://g.co/kgs/kH3AAW" target="_blank">See at Google</a></p>
            </div>
            <ul>
              <li><span>R</span></li>
              <li>
                <h5>Reshma mansoori</h5>
                <p>4 weeks ago</p>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-10 col-md-4">
          <div class="testi_card">
            <div class="testi_card_1">
              <ul>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
              </ul>
              <p>Best in class specialy the staff support is good... <a href="https://g.co/kgs/kpUvkJ" target="_blank">See at Google</a></p>
            </div>
            <ul>
              <li><span>S</span></li>
              <li>
                <h5>Shri R D technologies</h5>
                <p>6 months ago</p>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-10 col-md-4">
          <div class="testi_card">
            <div class="testi_card_1">
              <ul>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
              </ul>
              <p>Really hardworking person and timely deliver to projects.Appreciate... <a href="https://g.co/kgs/Ur3g7H" target="_blank">See at Google</a></p>
            </div>
            <ul>
              <li><span>K</span></li>
              <li>
                <h5>Kumar Aman</h5>
                <p>a week ago</p>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- <div class="carousel-item">
    <div class="row">
        <div class="col-md-4">
          <div class="testi_card">
            <div class="testi_card_1">
              <ul>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
              </ul>
              <p>Backend support is very good <a href="https://g.co/kgs/uDEkBD" target="_blank">See at Google</a></p>
            </div>
            <ul>
              <li><span>S</span></li>
              <li>
                <h5>SIDHARTH KUMAR</h5>
                <p>6 months ago</p>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-md-4">
          <div class="testi_card">
            <div class="testi_card_1">
              <ul>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
              </ul>
              <p><a href="https://g.co/kgs/22Xy8f" target="_blank">See at Google</a></p>
            </div>
            <ul>
              <li><span>R</span></li>
              <li>
                <h5>Rehman Ansari</h5>
                <p>6 months ago</p>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-md-4">
          <div class="testi_card">
            <div class="testi_card_1">
              <ul>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
                <li><img src="assets/img/star.svg" alt=""></li>
              </ul>
              <p><a href="https://g.co/kgs/TU4hUF" target="_blank">See at Google</a></p>
            </div>
            <ul>
              <li><span>S</span></li>
              <li>
                <h5>Satgur Singh</h5>
                <p>6 months ago</p>
              </li>
            </ul>
          </div>
        </div>
      </div>
  </div> -->
</div>